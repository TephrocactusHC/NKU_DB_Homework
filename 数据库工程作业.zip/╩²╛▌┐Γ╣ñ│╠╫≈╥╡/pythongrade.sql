INSERT INTO `pythongrade` (`SNO`, `GRADE`) VALUES ('S1', 0);
INSERT INTO `pythongrade` (`SNO`, `GRADE`) VALUES ('S2', 0);
INSERT INTO `pythongrade` (`SNO`, `GRADE`) VALUES ('S8', 0);
INSERT INTO `pythongrade` (`SNO`, `GRADE`) VALUES ('S7', 80);
